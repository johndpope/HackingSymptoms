import os

# for local use only (uncomment below)
#text_analytics_endpoint = "https://ta4h-app-service.azurewebsites.net/text/analytics/v3.0-preview.1/domains/health"

# for deployed use (uncomment below)
text_analytics_endpoint = str(os.environ["text_analytics_endpoint"])