import logging
import json
import azure.functions as func
import subprocess
from clinphen import clinphen_process

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    text = req.get_body()
    if not text:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            text = req_body.get('data')
            

    if text:

        ### Writing the input text as a file
        json_text = json.loads(text)
        data = json_text['data']
   
        ### Executing ClinPhen and getting the output as a dictionary
        
        out = clinphen_process(data)
        line_out = out.split('\n')
        
        output = {}
        output['status'] = 200
        result = []
        for lin in line_out[1:]:
            if len(lin) > 0:
                result_in = {}
                lin = lin.split('\t') 
                result_in['id'] = lin[0]
                result_in['concept'] = lin[1]
                result_in['No. of Occurences'] = lin[2]
                result_in['Earliness'] = lin[3]
                result.append(result_in)

        output['Result'] = result
        output['message'] = None
        output['exception'] = None
        output = json.dumps(output)
        return func.HttpResponse(output, headers={"Content-Type": "application/json"})
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass an input of text.",
             status_code=200
        )
